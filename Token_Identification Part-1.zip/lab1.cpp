#include <iostream>

#include <string>
using namespace std;

bool isNumeric(const  string& input_str)
{

    if (input_str.empty())
    {

        return false;

    }

    size_t index = 0;

    if (input_str[0] == '-')
    {

        index = 1;

    }
    bool hasDecimal = false;
    for (; index < input_str.length(); ++index)
    {

        char currentChar = input_str[index];

        if (currentChar >= '0' && currentChar <= '9')
        {

            continue;

        }

        if (currentChar == '.' && !hasDecimal)
        {

            hasDecimal = true;

            continue;

        }

        return false;
    }

    return true;

}

int main()
{

     string input_str;

     cout << "Enter a string: ";

     cin >> input_str;

    if (isNumeric(input_str))
    {

         cout << "The string is numeric." <<  endl;

    }
    else
    {

         cout << "The string is not numeric." <<  endl;

    }

    return 0;

}
